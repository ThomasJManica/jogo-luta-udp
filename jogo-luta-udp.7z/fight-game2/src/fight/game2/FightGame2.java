package fight.game2;

import javax.swing.JFrame;

public class FightGame2 {

    public static void main(String[] args) {
        JFrame jogo = new TelaJogo();
        jogo.setVisible(true);
    }
}
