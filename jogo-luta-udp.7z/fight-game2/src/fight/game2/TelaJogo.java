package fight.game2;

import java.awt.event.KeyEvent;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class TelaJogo extends JFrame implements Runnable {

    private JLabel playerOne = null;
    private JLabel playerTwo = null;

    public TelaJogo() {
        initComponents();
        initPersonagens();
        
        new Thread(this).start();
    }

    public void initPersonagens() {
        playerOne = new javax.swing.JLabel();
        playerOne.setIcon(new ImageIcon(getClass().getResource("/fight/game2/parado.gif")));
        playerOne.setBounds(100, 100, 150, 170);

        lbFundo.add(playerOne);

        playerTwo = new javax.swing.JLabel();
        playerTwo.setIcon(new ImageIcon(getClass().getResource("/fight/game2/parado180.gif")));
        playerTwo.setBounds(500, 100, 150, 170);

        lbFundo.add(playerTwo);
    }

    public void receberComandos() {
        try {
            DatagramSocket serverSocket = new DatagramSocket(8000);
            byte[] bufferEntrada = new byte[1024];

            while (true) {
                DatagramPacket receivePacket = new DatagramPacket(bufferEntrada, bufferEntrada.length);
                serverSocket.receive(receivePacket);

                String recebido = new String(bufferEntrada,0,receivePacket.getLength());
                System.out.println("Recebido: " + recebido);

                switch (recebido) {
                    case "direita":
                        playerTwo.setIcon(new ImageIcon(getClass().getResource("/fight/game2/andando_direita180.gif")));
                        playerTwo.setLocation(playerTwo.getX() + 4, playerTwo.getY());
                        break;
                    case "esquerda":
                        playerTwo.setIcon(new ImageIcon(getClass().getResource("/fight/game2/andando_esquerda180.gif")));
                        playerTwo.setLocation(playerTwo.getX() - 4, playerTwo.getY());
                        break;

                    case "socar":
                        playerTwo.setIcon(new ImageIcon(getClass().getResource("/fight/game2/atacando180.gif")));
                        break;
                }

                playerTwo.setIcon(new ImageIcon(getClass().getResource("/fight/game2/parado180.gif")));

                InetAddress ipCliente = receivePacket.getAddress();
                int portaCliente = receivePacket.getPort();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lbFundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(700, 300));
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                teclaPresionada(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                teclaSolta(evt);
            }
        });

        lbFundo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbFundo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fight/game2/fundo.jpg"))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lbFundo)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lbFundo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void teclaPresionada(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_teclaPresionada
        if (evt.getKeyCode() == KeyEvent.VK_RIGHT) {
            playerOne.setIcon(new ImageIcon(getClass().getResource("/fight/game2/andando_direita.gif")));
            playerOne.setLocation(playerOne.getX() + 4, playerOne.getY());
        }

        if (evt.getKeyCode() == KeyEvent.VK_LEFT) {
            playerOne.setIcon(new ImageIcon(getClass().getResource("/fight/game2/andando_esquerda.gif")));
            playerOne.setLocation(playerOne.getX() - 4, playerOne.getY());
        }

        if (evt.getKeyCode() == KeyEvent.VK_SPACE) {
            playerOne.setIcon(new ImageIcon(getClass().getResource("/fight/game2/atacando.gif")));
        }
    }//GEN-LAST:event_teclaPresionada

    private void teclaSolta(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_teclaSolta
        playerOne.setIcon(new ImageIcon(getClass().getResource("/fight/game2/parado.gif")));
    }//GEN-LAST:event_teclaSolta

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaJogo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel lbFundo;
    // End of variables declaration//GEN-END:variables

    @Override
    public void run() {
        while (true) {
            receberComandos();
        }
    }
}

/* 
        if (evt.getKeyCode() == KeyEvent.VK_RIGHT) {
            playerOne.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fight/game2/andando_direita.gif")));
            playerOne.setLocation(playerOne.getX() + 4, playerOne.getY());
        }

        if (evt.getKeyCode() == KeyEvent.VK_LEFT) {
            playerOne.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fight/game2/andando_esquerda.gif")));
            playerOne.setLocation(playerOne.getX() - 4, playerOne.getY());
        }
        
        if (evt.getKeyCode() == KeyEvent.VK_SPACE) {
            playerOne.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fight/game2/atacando.gif")));
        }
 */
